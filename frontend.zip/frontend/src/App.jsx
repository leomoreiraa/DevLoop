import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext'; // Import useAuth

// Import Page Components
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardLayout from './layouts/DashboardLayout'; // Layout for authenticated routes

// Placeholder components for pages not yet implemented
const DashboardPage = () => <div className="p-4"><h2>Dashboard</h2><p>Welcome! Content based on role goes here.</p></div>;
const ProfilePage = () => <div className="p-4"><h2>My Profile</h2><p>User profile details and edit form.</p></div>;
const MentorsPage = () => <div className="p-4"><h2>Find Mentors</h2><p>List of mentors with search/filter options.</p></div>;
const MentorProfilePage = () => <div className="p-4"><h2>Mentor Profile</h2><p>Detailed mentor profile, reviews, availability.</p></div>;
const AvailabilityPage = () => <div className="p-4"><h2>Manage Availability</h2><p>Calendar/List to manage mentor availability slots.</p></div>;
const SessionsPage = () => <div className="p-4"><h2>My Sessions</h2><p>List of past and upcoming sessions.</p></div>;
const SessionDetailPage = () => <div className="p-4"><h2>Session Details</h2><p>Session info, chat interface, review section.</p></div>;
const NotFoundPage = () => <div className="p-4 text-center"><h2>404 - Not Found</h2><p>The page you are looking for does not exist.</p></div>;

// Wrapper for protected routes
function ProtectedRoute({ children }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    // Optional: Show a loading spinner while checking auth status
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return isAuthenticated ? children : <Navigate to="/login" replace />;
}

// Wrapper for role-specific routes
function RoleRoute({ allowedRoles, children }) {
    const { user, loading } = useAuth();

    if (loading) {
        return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
    }

    return user && allowedRoles.includes(user.role) ? children : <Navigate to="/dashboard" replace />;
    // Redirect to dashboard if role doesn't match
}


function App() {
  const { user } = useAuth(); // Get user info for role-based routing

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      {/* Protected Routes - Use DashboardLayout */}
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <DashboardPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <ProfilePage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
       <Route
        path="/sessions"
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <SessionsPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />
       <Route
        path="/sessions/:id"
        element={
          <ProtectedRoute>
            <DashboardLayout>
              <SessionDetailPage />
            </DashboardLayout>
          </ProtectedRoute>
        }
      />

      {/* Mentee Routes */}
      <Route
        path="/mentors"
        element={
          <ProtectedRoute>
            <RoleRoute allowedRoles={['MENTEE']}>
                <DashboardLayout>
                    <MentorsPage />
                </DashboardLayout>
            </RoleRoute>
          </ProtectedRoute>
        }
      />
       <Route
        path="/mentors/:id"
        element={
          <ProtectedRoute>
             <RoleRoute allowedRoles={['MENTEE']}>
                <DashboardLayout>
                    <MentorProfilePage />
                </DashboardLayout>
            </RoleRoute>
          </ProtectedRoute>
        }
      />

      {/* Mentor Routes */}
      <Route
        path="/availability"
        element={
          <ProtectedRoute>
            <RoleRoute allowedRoles={['MENTOR']}>
                <DashboardLayout>
                    <AvailabilityPage />
                </DashboardLayout>
            </RoleRoute>
          </ProtectedRoute>
        }
      />

      {/* Catch-all Not Found Route */}
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

export default App;

