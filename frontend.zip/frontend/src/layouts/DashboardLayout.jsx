import React from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

// Placeholder icons (replace with actual icons from a library like react-icons)
const DashboardIcon = () => <span>📊</span>;
const ProfileIcon = () => <span>👤</span>;
const SessionsIcon = () => <span>📅</span>;
const MentorsIcon = () => <span>👥</span>;
const AvailabilityIcon = () => <span>⏰</span>;
const LogoutIcon = () => <span>🚪</span>;

// Pastel accent colors for sidebar buttons
const accentColors = [
  'bg-[#A7C7E7]', // pastel blue
  'bg-[#F9D5A7]', // pastel orange
  'bg-[#B5EAD7]', // pastel green
  'bg-[#FFDAC1]', // pastel peach
  'bg-[#E2F0CB]', // pastel lime
];

function DashboardLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  // Sidebar links with accent color index
  const sidebarLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: <DashboardIcon />, accent: 0 },
    { path: '/profile', label: 'Meu Perfil', icon: <ProfileIcon />, accent: 1 },
    { path: '/sessions', label: 'Minhas Sessões', icon: <SessionsIcon />, accent: 2 },
  ];

  if (user?.role === 'MENTEE') {
    sidebarLinks.push({ path: '/mentors', label: 'Buscar Mentores', icon: <MentorsIcon />, accent: 3 });
  }

  if (user?.role === 'MENTOR') {
    sidebarLinks.push({ path: '/availability', label: 'Disponibilidade', icon: <AvailabilityIcon />, accent: 4 });
  }

  return (
    <div className="flex h-screen" style={{ background: '#F7F6F3', fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif" }}>
      {/* Sidebar */}
      <aside className="w-64 flex flex-col shadow-md" style={{ background: '#FAFAF7' }}>
        <div className="p-4 border-b border-[#ECECEC]">
          <h1 className="text-2xl font-bold" style={{ color: '#252525', letterSpacing: '-0.5px' }}>DevLoop</h1>
        </div>
        <nav className="flex-1 mt-4 px-2 space-y-2">
          {sidebarLinks.map((link, idx) => (
            <NavLink
              key={link.path}
              to={link.path}
              className={({ isActive }) =>
                `flex items-center px-3 py-2 rounded-md transition duration-150 ease-in-out group relative
                ${isActive ? 'bg-[#ECECEC] text-[#252525] font-semibold' : 'text-[#252525] hover:bg-[#F0EFEB]'}
                `
              }
              style={{ fontSize: '1.08rem', fontWeight: 500, outline: 'none' }}
            >
              {/* Accent bar */}
              <span
                className={`absolute left-0 top-0 h-full w-2 rounded-r-lg ${accentColors[link.accent]}`}
                aria-hidden="true"
              />
              <span className="ml-4 mr-3 h-6 w-6">{link.icon}</span>
              {link.label}
            </NavLink>
          ))}
        </nav>
        {/* Logout Button */}
        <div className="p-2 border-t border-[#ECECEC] mt-auto">
          <button
            onClick={handleLogout}
            className="flex items-center w-full px-3 py-2 text-[#252525] rounded-md hover:bg-[#FFE5E5] hover:text-red-700 transition duration-150 ease-in-out group relative font-medium"
            style={{ fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif" }}
          >
            {/* Accent bar for logout */}
            <span className="absolute left-0 top-0 h-full w-2 rounded-r-lg bg-[#FFB3B3]" aria-hidden="true" />
            <span className="ml-4 mr-3 h-6 w-6"><LogoutIcon /></span>
            Sair
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-8" style={{ color: '#252525', background: '#F7F6F3' }}>
        <Outlet />
      </main>
    </div>
  );
}

export default DashboardLayout;

