import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios'; // Assuming axios for API calls

const AuthContext = createContext(null);

// Base URL for the backend API
const API_URL = 'http://localhost:8080'; // Adjust if backend runs elsewhere

export const AuthProvider = ({ children }) => {
  const [token, setToken] = useState(localStorage.getItem('authToken'));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true); // To check initial auth status

  // Configure axios instance for authenticated requests
  const apiClient = axios.create({
    baseURL: API_URL,
  });

  apiClient.interceptors.request.use(
    (config) => {
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  useEffect(() => {
    const fetchUser = async () => {
      if (token) {
        try {
          // Fetch user data using the token
          const response = await apiClient.get('/api/users/me');
          setUser(response.data);
        } catch (error) {
          console.error('Failed to fetch user data:', error);
          // Token might be invalid/expired, clear it
          logout();
        }
      }
      setLoading(false);
    };

    fetchUser();
  }, [token]); // Re-run when token changes

  const login = (newToken) => {
    localStorage.setItem('authToken', newToken);
    setToken(newToken);
    // User data will be fetched by the useEffect hook
  };

  const logout = () => {
    localStorage.removeItem('authToken');
    setToken(null);
    setUser(null);
  };

  const value = {
    token,
    user,
    isAuthenticated: !!token,
    loading,
    login,
    logout,
    apiClient, // Provide the configured axios instance
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};

