import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';

function ProfilePage() {
  const { user, apiClient, loading: authLoading, logout } = useAuth();
  const [profileData, setProfileData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({ username: '', email: '' }); // Add more fields as needed

  useEffect(() => {
    if (!authLoading && user) {
      // Use the user data from context initially
      setProfileData(user);
      setFormData({ username: user.username, email: user.email });
      setIsLoading(false);
    } else if (!authLoading && !user) {
        // Handle case where user is not logged in (should be caught by ProtectedRoute)
        setError('Usuário não autenticado.');
        setIsLoading(false);
    }
  }, [user, authLoading]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      // Assuming the API allows updating username/email via PUT /api/users/{id}
      // Note: Updating email/password might require re-authentication or specific flows
      const response = await apiClient.put(`/api/users/${user.id}`, {
        ...profileData, // Send existing data
        username: formData.username, // Send updated fields
        email: formData.email
        // Add other updatable fields here
      });
      setProfileData(response.data); // Update local state with response
      setFormData({ username: response.data.username, email: response.data.email });
      setIsEditing(false);
      // Optional: Maybe refresh user in AuthContext if critical data changed
      alert('Perfil atualizado com sucesso!');
    } catch (err) {
      console.error('Failed to update profile:', err);
      setError('Falha ao atualizar o perfil. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading || authLoading) {
    return <div className="p-4">Carregando perfil...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">Erro: {error}</div>;
  }

  if (!profileData) {
    return <div className="p-4">Não foi possível carregar os dados do perfil.</div>;
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-6">Meu Perfil</h2>
      <div className="bg-white p-6 rounded-lg shadow max-w-lg">
        {isEditing ? (
          <form onSubmit={handleUpdateProfile}>
            <div className="mb-4">
              <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-1">Nome de Usuário</label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleInputChange}
                required
                disabled={isLoading}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
              />
            </div>
            <div className="mb-4">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                disabled={isLoading} // Consider disabling email change or adding verification
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
              />
            </div>
            {/* Add other editable fields here */} 
            <div className="flex justify-end space-x-3 mt-6">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                disabled={isLoading}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition duration-150 disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-150 disabled:opacity-50"
              >
                {isLoading ? 'Salvando...' : 'Salvar Alterações'}
              </button>
            </div>
             {error && <p className="text-red-600 text-sm mt-4">{error}</p>}
          </form>
        ) : (
          <div className="space-y-3">
            <p><strong>Nome de Usuário:</strong> {profileData.username}</p>
            <p><strong>Email:</strong> {profileData.email}</p>
            <p><strong>Role:</strong> {profileData.role}</p>
            {/* Display other profile fields */} 
            <button
              onClick={() => setIsEditing(true)}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition duration-150"
            >
              Editar Perfil
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default ProfilePage;

