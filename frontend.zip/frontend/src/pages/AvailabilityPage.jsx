import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import availabilityService from '../services/availabilityService';

// Basic Date/Time formatting helper
const formatDateTime = (isoString) => {
  if (!isoString) return 'N/A';
  try {
    return new Date(isoString).toLocaleString('pt-BR', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  } catch (e) {
    return 'Data inválida';
  }
};

function AvailabilityPage() {
  const { user, apiClient, loading: authLoading } = useAuth();
  const [availabilities, setAvailabilities] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [newStartTime, setNewStartTime] = useState('');
  const [newEndTime, setNewEndTime] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchAvailabilities = async () => {
    if (!apiClient || !user) return;
    setIsLoading(true);
    setError('');
    try {
      const data = await availabilityService.getAvailabilities(apiClient, user.id);
      // Sort availabilities by start time
      data.sort((a, b) => new Date(a.start) - new Date(b.start));
      setAvailabilities(data);
    } catch (err) {
      console.error("Failed to fetch availabilities:", err);
      setError('Não foi possível carregar suas disponibilidades.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!authLoading) {
      fetchAvailabilities();
    }
  }, [apiClient, user, authLoading]);

  const handleAddAvailability = async (e) => {
    e.preventDefault();
    if (!newStartTime || !newEndTime) {
      setError('Por favor, preencha as datas e horas de início e fim.');
      return;
    }
    // Basic validation: end time must be after start time
    if (new Date(newEndTime) <= new Date(newStartTime)) {
        setError('A data/hora final deve ser posterior à data/hora inicial.');
        return;
    }

    setIsSubmitting(true);
    setError('');
    try {
      await availabilityService.createAvailability(apiClient, {
        start: new Date(newStartTime).toISOString(),
        end: new Date(newEndTime).toISOString(),
      });
      setNewStartTime('');
      setNewEndTime('');
      fetchAvailabilities(); // Refresh the list
      alert('Disponibilidade adicionada com sucesso!');
    } catch (err) {
      console.error("Failed to add availability:", err);
      setError('Falha ao adicionar disponibilidade. Tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Pastel accent for the card border
  const pastelAccent = "#A7C7E7"; // pastel blue

  if (authLoading || isLoading) {
    return (
      <div className="flex items-center justify-center h-full" style={{ fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif", color: "#252525" }}>
        Carregando disponibilidades...
      </div>
    );
  }

  return (
    <div
      className="max-w-3xl mx-auto py-8"
      style={{
        fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
        color: "#252525",
      }}
    >
      <h2 className="text-3xl font-bold mb-8" style={{ letterSpacing: "-1px" }}>
        Gerenciar Disponibilidade
      </h2>

      {/* Form to Add New Availability */}
      <div
        className="mb-10 shadow"
        style={{
          background: "#FAFAF7",
          borderRadius: "1.1rem",
          borderLeft: `10px solid ${pastelAccent}`,
          boxShadow: "0 2px 8px 0 rgba(60,60,60,0.04)",
        }}
      >
        <div className="p-7">
          <h3 className="text-xl font-semibold mb-4" style={{ color: "#252525" }}>
            Adicionar Novo Horário
          </h3>
          {error && (
            <p className="bg-[#FFE5E5] text-red-700 p-3 rounded mb-4 text-sm font-medium">
              {error}
            </p>
          )}
          <form onSubmit={handleAddAvailability} className="space-y-5">
            <div>
              <label htmlFor="startTime" className="block text-sm font-medium mb-1" style={{ color: "#252525" }}>
                Início
              </label>
              <input
                type="datetime-local"
                id="startTime"
                value={newStartTime}
                onChange={(e) => setNewStartTime(e.target.value)}
                required
                disabled={isSubmitting}
                className="w-full px-3 py-2 border border-[#ECECEC] rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C7E7] focus:border-[#A7C7E7] disabled:bg-[#F7F6F3] bg-[#F7F6F3] text-[#252525]"
                style={{ fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif" }}
              />
            </div>
            <div>
              <label htmlFor="endTime" className="block text-sm font-medium mb-1" style={{ color: "#252525" }}>
                Fim
              </label>
              <input
                type="datetime-local"
                id="endTime"
                value={newEndTime}
                onChange={(e) => setNewEndTime(e.target.value)}
                required
                disabled={isSubmitting}
                className="w-full px-3 py-2 border border-[#ECECEC] rounded-md focus:outline-none focus:ring-2 focus:ring-[#A7C7E7] focus:border-[#A7C7E7] disabled:bg-[#F7F6F3] bg-[#F7F6F3] text-[#252525]"
                style={{ fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif" }}
              />
            </div>
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto px-5 py-2 rounded-md font-semibold transition duration-150"
              style={{
                background: "#B5EAD7",
                color: "#252525",
                fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
                boxShadow: "0 1px 4px 0 rgba(60,60,60,0.04)",
                opacity: isSubmitting ? 0.7 : 1,
              }}
            >
              {isSubmitting ? 'Adicionando...' : 'Adicionar Disponibilidade'}
            </button>
          </form>
        </div>
      </div>

      {/* List of Existing Availabilities */}
      <div
        className="shadow"
        style={{
          background: "#FAFAF7",
          borderRadius: "1.1rem",
          borderLeft: "10px solid #F9D5A7", // pastel orange
          boxShadow: "0 2px 8px 0 rgba(60,60,60,0.04)",
        }}
      >
        <div className="p-7">
          <h3 className="text-xl font-semibold mb-4" style={{ color: "#252525" }}>
            Meus Horários Disponíveis
          </h3>
          {availabilities.length === 0 ? (
            <p className="text-[#888]">Você ainda não adicionou nenhum horário disponível.</p>
          ) : (
            <ul className="space-y-3">
              {availabilities.map((avail) => (
                <li
                  key={avail.id}
                  className="flex justify-between items-center p-3 rounded-md"
                  style={{
                    background: "#F7F6F3",
                    border: "1.5px solid #ECECEC",
                    color: "#252525",
                    fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
                  }}
                >
                  <span>
                    De <span className="font-medium">{formatDateTime(avail.start)}</span> até <span className="font-medium">{formatDateTime(avail.end)}</span>
                  </span>
                  {/* <button className="text-red-500 hover:text-red-700 text-sm">Excluir</button> */}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

export default AvailabilityPage;

