import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import sessionService from '../services/sessionService';

// Basic Date/Time formatting helper
const formatDateTime = (isoString) => {
  if (!isoString) return 'N/A';
  try {
    return new Date(isoString).toLocaleString('pt-BR', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  } catch (e) {
    return 'Data inválida';
  }
};

function SessionsPage() {
  const { user, apiClient, loading: authLoading } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchSessions = async () => {
      if (!apiClient || authLoading || !user) return;

      setIsLoading(true);
      setError('');
      try {
        // Fetch all sessions and filter client-side
        // Ideally, backend could provide filtered endpoints like /sessions/my or /sessions?userId=...
        const allSessions = await sessionService.getAllSessions(apiClient);
        const userSessions = allSessions.filter(
          (session) => session.mentor?.id === user.id || session.mentee?.id === user.id
        );
        // Sort sessions by scheduled time (newest first)
        userSessions.sort((a, b) => new Date(b.scheduledTime) - new Date(a.scheduledTime));
        setSessions(userSessions);
      } catch (err) {
        console.error("Failed to fetch sessions:", err);
        setError('Não foi possível carregar suas sessões.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchSessions();
  }, [apiClient, user, authLoading]);

  if (isLoading || authLoading) {
    return <div className="p-4">Carregando sessões...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">Erro: {error}</div>;
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-6">Minhas Sessões</h2>

      {sessions.length === 0 ? (
        <p className="text-gray-600">Você não possui nenhuma sessão agendada.</p>
      ) : (
        <div className="space-y-4">
          {sessions.map((session) => (
            <div key={session.id} className="bg-white p-5 rounded-lg shadow">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-lg font-semibold">Sessão sobre "{session.topic || 'Não especificado'}"</h3>
                <span className="text-sm text-gray-500">{formatDateTime(session.scheduledTime)}</span>
              </div>
              <div className="text-sm text-gray-700 mb-3">
                {user?.role === 'MENTOR' ? (
                  <p>Mentee: {session.mentee?.username || 'N/A'}</p>
                ) : (
                  <p>Mentor: {session.mentor?.username || 'N/A'}</p>
                )}
                {/* Add session status if available in the entity */}
                {/* <p>Status: {session.status || 'Agendada'}</p> */}
              </div>
              <Link
                to={`/sessions/${session.id}`}
                className="inline-block text-sm px-3 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition duration-150"
              >
                Ver Detalhes / Chat
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default SessionsPage;

