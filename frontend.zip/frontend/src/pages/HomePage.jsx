import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center"
      style={{
        background: "#F7F6F3",
        color: "#252525",
        fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
      }}
    >
      {/* Header */}
      <header className="w-full flex justify-center py-8 mb-2">
        <div className="flex items-center gap-3">
          {/* Ícone ou logo sutil */}
          <span
            className="inline-flex items-center justify-center rounded-full"
            style={{
              background: "#A7C7E7",
              width: 48,
              height: 48,
              fontSize: 28,
              color: "#252525",
              fontWeight: 700,
              letterSpacing: "-1px",
              boxShadow: "0 1px 4px 0 rgba(60,60,60,0.04)",
            }}
          >
            DL
          </span>
          <span
            className="text-2xl font-bold tracking-tight"
            style={{
              color: "#252525",
              fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
              letterSpacing: "-1px",
            }}
          >
            DevLoop
          </span>
        </div>
      </header>

      {/* Main Card */}
      <main
        className="text-center max-w-2xl mx-auto px-4 py-12 shadow"
        style={{
          background: "#FAFAF7",
          borderRadius: "1.2rem",
          borderLeft: "10px solid #A7C7E7",
          boxShadow: "0 2px 8px 0 rgba(60,60,60,0.04)",
        }}
      >
        <h1
          className="text-4xl md:text-5xl font-extrabold mb-4"
          style={{
            letterSpacing: "-1.5px",
            color: "#252525",
            fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
            lineHeight: 1.1,
          }}
        >
          <span style={{ color: "#A7C7E7" }}>Conecte</span> <span style={{ color: "#252525" }}>mentores</span> <br />
          <span style={{ color: "#252525" }}>e</span> <span style={{ color: "#B5EAD7" }}>mentees</span>
        </h1>
        <p
          className="text-lg mb-8"
          style={{
            color: "#555",
            fontWeight: 500,
            fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
            lineHeight: 1.6,
          }}
        >
          Descubra uma nova forma de crescer profissionalmente.<br />
          <span style={{ color: "#252525", fontWeight: 600 }}>
            Encontre o mentor ideal para impulsionar sua carreira
          </span>{" "}
          ou compartilhe seu conhecimento e ajude outras pessoas a evoluir.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4 mb-2">
          <Link
            to="/login"
            className="px-7 py-3 rounded-md font-semibold transition duration-150 shadow"
            style={{
              background: "#B5EAD7", // pastel green
              color: "#252525",
              fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
              fontSize: "1.15rem",
              boxShadow: "0 1px 4px 0 rgba(60,60,60,0.04)",
              border: "none",
            }}
          >
            Entrar
          </Link>
          <Link
            to="/register"
            className="px-7 py-3 rounded-md font-semibold transition duration-150 shadow"
            style={{
              background: "#F9D5A7", // pastel orange
              color: "#252525",
              fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
              fontSize: "1.15rem",
              boxShadow: "0 1px 4px 0 rgba(60,60,60,0.04)",
              border: "none",
            }}
          >
            Registrar-se
          </Link>
        </div>
        <div className="mt-8 flex flex-col gap-2 text-left text-base" style={{ color: "#888" }}>
          <div>
            <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ background: "#A7C7E7" }}></span>
            <span>Mentorias personalizadas para todas as áreas</span>
          </div>
          <div>
            <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ background: "#B5EAD7" }}></span>
            <span>Encontre ou seja um mentor em poucos cliques</span>
          </div>
          <div>
            <span className="inline-block w-2 h-2 rounded-full mr-2" style={{ background: "#F9D5A7" }}></span>
            <span>Plataforma moderna, acessível e gratuita</span>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-10 text-[#888] text-sm">
        © 2025 DevLoop &middot; Feito com <span style={{ color: "#F9D5A7" }}>♥</span>
      </footer>
    </div>
  );
}

export default HomePage;