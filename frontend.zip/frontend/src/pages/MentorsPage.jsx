import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import userService from '../services/userService'; // Assuming userService is created

function MentorsPage() {
  const { apiClient, loading: authLoading } = useAuth();
  const [mentors, setMentors] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchMentors = async () => {
      if (!apiClient || authLoading) return; // Wait for apiClient and auth check

      setIsLoading(true);
      setError('');
      try {
        // Fetch all users and filter for mentors client-side, or adjust API if possible
        // Ideally, the backend would have an endpoint like /api/users?role=MENTOR
        const allUsers = await userService.getUsers(apiClient);
        const mentorUsers = allUsers.filter(user => user.role === 'MENTOR');
        setMentors(mentorUsers);
      } catch (err) {
        console.error("Failed to fetch mentors:", err);
        setError('Não foi possível carregar a lista de mentores.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchMentors();
  }, [apiClient, authLoading]);

  if (isLoading || authLoading) {
    return <div className="p-4">Carregando mentores...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">Erro: {error}</div>;
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-6">Encontrar Mentores</h2>
      
      {mentors.length === 0 ? (
        <p className="text-gray-600">Nenhum mentor encontrado no momento.</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mentors.map((mentor) => (
            <div key={mentor.id} className="bg-white p-5 rounded-lg shadow hover:shadow-md transition-shadow duration-200">
              <h3 className="text-lg font-semibold mb-2">{mentor.username}</h3>
              {/* Add more mentor info here if available (e.g., expertise, rating) */}
              <p className="text-sm text-gray-500 mb-3">Email: {mentor.email}</p> 
              <Link 
                to={`/mentors/${mentor.id}`}
                className="inline-block text-sm px-3 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition duration-150"
              >
                Ver Perfil e Disponibilidade
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default MentorsPage;

