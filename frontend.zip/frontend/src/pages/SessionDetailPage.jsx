import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import sessionService from '../services/sessionService';
import reviewService from '../services/reviewService';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

// Basic Date/Time formatting helper
const formatDateTime = (isoString) => {
  if (!isoString) return 'N/A';
  try {
    return new Date(isoString).toLocaleString('pt-BR', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  } catch (e) {
    return 'Data inválida';
  }
};

function SessionDetailPage() {
  const { id: sessionId } = useParams();
  const { user, apiClient, loading: authLoading, token } = useAuth();
  const [session, setSession] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewError, setReviewError] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  const stompClientRef = useRef(null);
  const messagesEndRef = useRef(null); // Ref to scroll chat to bottom

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }

  useEffect(scrollToBottom, [messages]); // Scroll when messages update

  // Fetch Session Details and Reviews
  const fetchSessionData = useCallback(async () => {
    if (!apiClient || authLoading || !sessionId) return;
    setIsLoading(true);
    setError('');
    try {
      const sessionData = await sessionService.getSessionById(apiClient, sessionId);
      setSession(sessionData);
      // Fetch reviews for this session
      const reviewData = await reviewService.getReviewsBySessionId(apiClient, sessionId);
      setReviews(reviewData);
    } catch (err) {
      console.error("Failed to fetch session data:", err);
      setError('Não foi possível carregar os detalhes da sessão.');
    } finally {
      setIsLoading(false);
    }
  }, [apiClient, sessionId, authLoading]);

  useEffect(() => {
    fetchSessionData();
  }, [fetchSessionData]);

  // WebSocket Connection
  useEffect(() => {
    if (!sessionId || !token || !user) return;

    const connectWebSocket = () => {
        // Use SockJS for potential fallback if native WebSockets aren't available/configured
        // Adjust URL to your backend WebSocket endpoint
        const socket = new SockJS("http://localhost:8081/ws"); 
        const stompClient = new Client({
            webSocketFactory: () => socket,
            connectHeaders: {
                Authorization: `Bearer ${token}`,
            },
            reconnectDelay: 5000,
            heartbeatIncoming: 4000,
            heartbeatOutgoing: 4000,
            onConnect: (frame) => {
                console.log('Connected via STOMP:', frame);
                stompClient.subscribe(`/topic/session/${sessionId}`, (message) => {
                    try {
                        const receivedMessage = JSON.parse(message.body);
                        // Ensure message has expected structure before adding
                        if (receivedMessage && receivedMessage.content && receivedMessage.sender) {
                             setMessages((prevMessages) => [...prevMessages, receivedMessage]);
                        } else {
                            console.warn("Received invalid message format:", message.body);
                        }
                    } catch (e) {
                        console.error("Could not parse received JSON message:", message.body, e);
                    }
                });
            },
            onStompError: (frame) => {
                console.error('Broker reported error: ' + frame.headers['message']);
                console.error('Additional details: ' + frame.body);
            },
            onWebSocketError: (event) => {
                 console.error('WebSocket error:', event);
            },
            onDisconnect: () => {
                console.log('Disconnected from STOMP');
            }
        });

        stompClient.activate();
        stompClientRef.current = stompClient;
    };

    connectWebSocket();

    // Cleanup on unmount
    return () => {
      if (stompClientRef.current && stompClientRef.current.connected) {
        stompClientRef.current.deactivate();
        console.log('WebSocket disconnected');
      }
    };
  }, [sessionId, token, user]); // Reconnect if session ID or token changes

  const handleSendMessage = () => {
    if (newMessage.trim() && stompClientRef.current && stompClientRef.current.connected && user) {
      try {
          const chatMessage = {
            senderId: user.id, // Send sender ID
            sessionId: parseInt(sessionId, 10),
            content: newMessage.trim(),
            // Backend should handle setting the User entity based on senderId and timestamp
          };
          stompClientRef.current.publish({
            destination: `/app/session/${sessionId}/send`,
            body: JSON.stringify(chatMessage),
          });
          setNewMessage('');
      } catch (error) {
          console.error("Failed to send message:", error);
          // Optionally show an error to the user
      }
    }
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (!reviewComment || reviewRating < 1 || reviewRating > 5) {
        setReviewError('Por favor, forneça uma nota (1-5) e um comentário.');
        return;
    }
    setIsSubmittingReview(true);
    setReviewError('');
    try {
        const reviewData = {
            sessionId: parseInt(sessionId, 10),
            mentorId: session.mentor.id, // Assuming session object has mentor with id
            rating: reviewRating,
            comment: reviewComment,
        };
        await reviewService.createReview(apiClient, reviewData);
        setReviewComment('');
        setReviewRating(5);
        alert('Avaliação enviada com sucesso!');
        // Refresh reviews
        const updatedReviews = await reviewService.getReviewsBySessionId(apiClient, sessionId);
        setReviews(updatedReviews);
    } catch (err) {
        console.error("Failed to submit review:", err);
        setReviewError(err.message || 'Falha ao enviar avaliação.');
    } finally {
        setIsSubmittingReview(false);
    }
  };

  if (isLoading || authLoading) {
    return <div className="p-4">Carregando detalhes da sessão...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">Erro: {error}</div>;
  }

  if (!session) {
    return <div className="p-4">Sessão não encontrada.</div>;
  }

  // Determine if the current user can review (usually the mentee)
  const canReview = user?.id === session.mentee?.id;
  // Check if the current user has already reviewed this session
  const hasReviewed = reviews.some(review => review.reviewerId === user?.id);

  return (
    <div className="p-4 flex flex-col lg:flex-row gap-6">
      {/* Session Details & Reviews */}
      <div className="lg:w-1/3 space-y-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4">Detalhes da Sessão</h2>
          <p><strong>Tópico:</strong> {session.topic || 'N/A'}</p>
          <p><strong>Mentor:</strong> {session.mentor?.username || 'N/A'}</p>
          <p><strong>Mentee:</strong> {session.mentee?.username || 'N/A'}</p>
          <p><strong>Agendada para:</strong> {formatDateTime(session.scheduledTime)}</p>
          {/* Add status if available */}
        </div>

        {/* Reviews Section */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-lg font-semibold mb-4">Avaliações</h3>
          {reviews.length === 0 ? (
            <p className="text-sm text-gray-500">Nenhuma avaliação ainda.</p>
          ) : (
            <ul className="space-y-3 mb-4">
              {reviews.map(review => (
                <li key={review.id} className="border-b pb-2">
                  <p className="font-medium">Nota: {review.rating}/5</p>
                  <p className="text-sm text-gray-700">"{review.comment}"</p>
                  {/* Optionally show reviewer name if needed */}
                </li>
              ))}
            </ul>
          )}

          {/* Add Review Form (only if mentee and hasn't reviewed yet) */}
          {canReview && !hasReviewed && (
            <form onSubmit={handleReviewSubmit} className="mt-4 pt-4 border-t">
              <h4 className="text-md font-semibold mb-2">Deixar uma Avaliação</h4>
              {reviewError && <p className="text-red-600 text-sm mb-2">{reviewError}</p>}
              <div className="mb-2">
                <label htmlFor="rating" className="block text-sm font-medium text-gray-700 mb-1">Nota (1-5)</label>
                <input
                  type="number"
                  id="rating"
                  min="1"
                  max="5"
                  value={reviewRating}
                  onChange={(e) => setReviewRating(parseInt(e.target.value, 10))}
                  required
                  disabled={isSubmittingReview}
                  className="w-full px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
                />
              </div>
              <div className="mb-3">
                <label htmlFor="comment" className="block text-sm font-medium text-gray-700 mb-1">Comentário</label>
                <textarea
                  id="comment"
                  rows="3"
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  required
                  disabled={isSubmittingReview}
                  className="w-full px-3 py-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-100"
                ></textarea>
              </div>
              <button
                type="submit"
                disabled={isSubmittingReview}
                className="px-4 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition duration-150 disabled:opacity-50"
              >
                {isSubmittingReview ? 'Enviando...' : 'Enviar Avaliação'}
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Chat Section */}
      <div className="lg:w-2/3 bg-white p-6 rounded-lg shadow flex flex-col h-[70vh]">
        <h2 className="text-xl font-semibold mb-4 border-b pb-2">Chat da Sessão</h2>
        <div className="flex-1 overflow-y-auto mb-4 pr-2 space-y-3">
          {messages.map((msg, index) => (
            <div
              key={index} // Use a more stable key if messages have IDs
              className={`flex ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[70%] p-3 rounded-lg ${msg.senderId === user?.id ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}
              >
                {/* Optionally display sender name if not the current user */}
                {/* {msg.senderId !== user?.id && <p className="text-xs font-semibold mb-1">{msg.sender?.username || 'Usuário'}</p>} */}
                <p>{msg.content}</p>
                {/* Optionally display timestamp */}
                {/* <p className="text-xs opacity-70 mt-1">{formatDateTime(msg.timestamp)}</p> */}
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} /> {/* Element to scroll to */}
        </div>
        <div className="mt-auto flex border-t pt-4">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Digite sua mensagem..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          />
          <button
            onClick={handleSendMessage}
            className="px-4 py-2 bg-blue-600 text-white rounded-r-md hover:bg-blue-700 transition duration-150"
          >
            Enviar
          </button>
        </div>
      </div>
    </div>
  );
}

export default SessionDetailPage;

