import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';

function DashboardPage() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div
        className="flex items-center justify-center h-full"
        style={{
          fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
          color: "#252525",
        }}
      >
        Carregando informações do usuário...
      </div>
    );
  }

  return (
    <div
      className="max-w-3xl mx-auto py-8"
      style={{
        fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
        color: "#252525",
      }}
    >
      <h2 className="text-3xl font-bold mb-6" style={{ letterSpacing: "-1px" }}>
        Dashboard
      </h2>
      <p className="mb-8 text-lg">Bem-vindo(a), <span className="font-semibold">{user.username}</span>!</p>

      {user.role === 'MENTEE' && (
        <div
          className="mb-10 shadow"
          style={{
            background: "#FAFAF7",
            borderRadius: "1.1rem",
            borderLeft: "10px solid #A7C7E7", // pastel blue
            boxShadow: "0 2px 8px 0 rgba(60,60,60,0.04)",
          }}
        >
          <div className="p-7">
            <h3 className="text-xl font-semibold mb-4" style={{ color: "#252525" }}>
              Ações Rápidas (Mentee)
            </h3>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <Link
                to="/mentors"
                className="px-5 py-2 rounded-md font-semibold transition duration-150 shadow"
                style={{
                  background: "#B5EAD7", // pastel green
                  color: "#252525",
                  fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
                  boxShadow: "0 1px 4px 0 rgba(60,60,60,0.04)",
                }}
              >
                Buscar Mentores
              </Link>
            </div>
            <div
              className="p-4 rounded-md"
              style={{
                background: "#F7F6F3",
                border: "1.5px solid #ECECEC",
                color: "#252525",
                fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
              }}
            >
              <span className="font-medium">Suas próximas sessões aparecerão aqui.</span>
            </div>
          </div>
        </div>
      )}

      {user.role === 'MENTOR' && (
        <div
          className="mb-10 shadow"
          style={{
            background: "#FAFAF7",
            borderRadius: "1.1rem",
            borderLeft: "10px solid #F9D5A7", // pastel orange
            boxShadow: "0 2px 8px 0 rgba(60,60,60,0.04)",
          }}
        >
          <div className="p-7">
            <h3 className="text-xl font-semibold mb-4" style={{ color: "#252525" }}>
              Ações Rápidas (Mentor)
            </h3>
            <div className="flex flex-col sm:flex-row gap-4 mb-6">
              <Link
                to="/availability"
                className="px-5 py-2 rounded-md font-semibold transition duration-150 shadow"
                style={{
                  background: "#A7C7E7", // pastel blue
                  color: "#252525",
                  fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
                  boxShadow: "0 1px 4px 0 rgba(60,60,60,0.04)",
                }}
              >
                Gerenciar Disponibilidade
              </Link>
            </div>
            <div
              className="p-4 rounded-md"
              style={{
                background: "#F7F6F3",
                border: "1.5px solid #ECECEC",
                color: "#252525",
                fontFamily: "'Inter', 'Segoe UI', Arial, sans-serif",
              }}
            >
              <span className="font-medium">Suas próximas sessões aparecerão aqui.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default DashboardPage;

