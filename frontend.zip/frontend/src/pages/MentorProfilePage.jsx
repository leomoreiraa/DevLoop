import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import userService from '../services/userService';
import availabilityService from '../services/availabilityService';
import sessionService from '../services/sessionService'; // To book sessions
// import reviewService from '../services/reviewService'; // Implement later for reviews

// Basic Date/Time formatting helper
const formatDateTime = (isoString) => {
  if (!isoString) return 'N/A';
  try {
    return new Date(isoString).toLocaleString('pt-BR', {
      dateStyle: 'short',
      timeStyle: 'short',
    });
  } catch (e) {
    return 'Data inválida';
  }
};

function MentorProfilePage() {
  const { id: mentorId } = useParams(); // Get mentor ID from URL
  const { user: currentUser, apiClient, loading: authLoading } = useAuth();
  const [mentor, setMentor] = useState(null);
  const [availabilities, setAvailabilities] = useState([]);
  // const [reviews, setReviews] = useState([]); // For later implementation
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [bookingSlot, setBookingSlot] = useState(null); // State to manage which slot is being booked
  const [bookingTopic, setBookingTopic] = useState('');
  const [isBooking, setIsBooking] = useState(false);
  const [bookingError, setBookingError] = useState('');

  useEffect(() => {
    const fetchMentorData = async () => {
      if (!apiClient || authLoading || !mentorId) return;
      setIsLoading(true);
      setError('');
      try {
        const [mentorData, availabilityData] = await Promise.all([
          userService.getUserById(apiClient, mentorId),
          availabilityService.getAvailabilities(apiClient, mentorId),
          // reviewService.getReviewsByMentorId(apiClient, mentorId) // Fetch reviews later
        ]);

        if (mentorData.role !== 'MENTOR') {
            throw new Error("Usuário não é um mentor.");
        }

        setMentor(mentorData);
        // Sort availabilities
        availabilityData.sort((a, b) => new Date(a.start) - new Date(b.start));
        setAvailabilities(availabilityData);
        // setReviews(reviewData);
      } catch (err) {
        console.error("Failed to fetch mentor data:", err);
        setError('Não foi possível carregar os dados do mentor.');
      } finally {
        setIsLoading(false);
      }
    };

    fetchMentorData();
  }, [apiClient, mentorId, authLoading]);

  const handleBookSession = async (availability) => {
    if (!bookingTopic) {
        setBookingError('Por favor, informe o tópico da mentoria.');
        return;
    }
    setIsBooking(true);
    setBookingError('');
    try {
        // The backend expects the scheduledTime to be within the availability slot.
        // For simplicity, we'll use the start time of the availability slot.
        // A more robust implementation might allow selecting a specific time within the slot.
        const sessionData = {
            mentor: { id: mentor.id },
            scheduledTime: availability.start, // Use the start time of the slot
            topic: bookingTopic,
        };
        await sessionService.createSession(apiClient, sessionData);
        alert('Sessão agendada com sucesso!');
        setBookingSlot(null); // Close booking form
        setBookingTopic('');
        // Refresh availabilities (the booked one should be gone)
        const updatedAvailabilities = await availabilityService.getAvailabilities(apiClient, mentorId);
        updatedAvailabilities.sort((a, b) => new Date(a.start) - new Date(b.start));
        setAvailabilities(updatedAvailabilities);

    } catch (err) {
        console.error("Failed to book session:", err);
        setBookingError(err.message || 'Falha ao agendar a sessão. Verifique a disponibilidade e tente novamente.');
    } finally {
        setIsBooking(false);
    }
  };

  if (isLoading || authLoading) {
    return <div className="p-4">Carregando perfil do mentor...</div>;
  }

  if (error) {
    return <div className="p-4 text-red-600">Erro: {error}</div>;
  }

  if (!mentor) {
    return <div className="p-4">Mentor não encontrado.</div>;
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-semibold mb-4">Perfil de {mentor.username}</h2>

      <div className="bg-white p-6 rounded-lg shadow mb-8">
        <h3 className="text-xl font-semibold mb-3">Informações</h3>
        <p><strong>Nome:</strong> {mentor.username}</p>
        <p><strong>Email:</strong> {mentor.email}</p>
        {/* Add more mentor details here if available */} 
      </div>

      {/* Availability Section - Only show booking for Mentees */}
      {currentUser?.role === 'MENTEE' && (
          <div className="bg-white p-6 rounded-lg shadow mb-8">
            <h3 className="text-xl font-semibold mb-4">Horários Disponíveis</h3>
            {availabilities.length === 0 ? (
              <p className="text-gray-600">Este mentor não possui horários disponíveis no momento.</p>
            ) : (
              <ul className="space-y-4">
                {availabilities.map((avail) => (
                  <li key={avail.id} className="p-4 border rounded-md bg-gray-50">
                    <p className="mb-2">
                      De <span className="font-medium">{formatDateTime(avail.start)}</span> até <span className="font-medium">{formatDateTime(avail.end)}</span>
                    </p>
                    {bookingSlot === avail.id ? (
                        <div className="mt-3 pt-3 border-t">
                            <label htmlFor={`topic-${avail.id}`} className="block text-sm font-medium text-gray-700 mb-1">Tópico da Mentoria:</label>
                            <input
                                type="text"
                                id={`topic-${avail.id}`}
                                value={bookingTopic}
                                onChange={(e) => setBookingTopic(e.target.value)}
                                required
                                disabled={isBooking}
                                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 mb-2 disabled:bg-gray-100"
                                placeholder="Ex: Revisão de Código, Carreira, etc."
                            />
                            {bookingError && <p className="text-red-600 text-sm mb-2">{bookingError}</p>}
                            <div className="flex space-x-2">
                                <button
                                    onClick={() => handleBookSession(avail)}
                                    disabled={isBooking}
                                    className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 transition duration-150 disabled:opacity-50"
                                >
                                    {isBooking ? 'Agendando...' : 'Confirmar Agendamento'}
                                </button>
                                <button
                                    onClick={() => { setBookingSlot(null); setBookingError(''); setBookingTopic(''); }}
                                    disabled={isBooking}
                                    className="px-3 py-1 bg-gray-200 text-gray-800 text-sm rounded hover:bg-gray-300 transition duration-150 disabled:opacity-50"
                                >
                                    Cancelar
                                </button>
                            </div>
                        </div>
                    ) : (
                        <button
                            onClick={() => { setBookingSlot(avail.id); setBookingError(''); setBookingTopic(''); }}
                            className="px-3 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600 transition duration-150"
                        >
                            Agendar neste horário
                        </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
      )}

      {/* Reviews Section (Placeholder) */}
      {/* <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Avaliações</h3>
        <p className="text-gray-600">Funcionalidade de avaliações será implementada aqui.</p>
         Render reviews list here 
      </div> */}
    </div>
  );
}

export default MentorProfilePage;

